function saveLogin(){
var user= document.getElementById('user');
var psw = document.getElementById('psw');

if(user !== "" ||  psw !== ""){
	var userValue = sessionStorage.getItem("username");
	var passwordValue = sessionStorage.getItem("password");
	if(user !== userValue && passwordValue !== psw){
		alert("The User or Password is incorrect");
	}
	else{
		alert("Login success");
	}
 }
}