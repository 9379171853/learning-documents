function clicked(){
var user= document.getElementById('user').value;
var mobile = document.getElementById('mNumber').value;
var address = document.getElementById('address').value;
var psw = document.getElementById('psw').value;
var cnfpsw = document.getElementById('cnfpsw').value;
var role= document.getElementById('role').value;

if(user == "" ){
	alert("Please enter the User Name/ Email");
	return
}


if(mobile == "" ){
	alert("Please enter the Mobile Number");
	return
}
if(address == "" ){
	alert("Please enter the Address");
	return
}
if(psw == "" ){
	alert("Please enter the Password");
	return
}
if(cnfpsw == "" ){
	alert("Please enter the Confirm password");
	return
}

if(role == "select"  ){
	alert("Please Select the Role");
	return
}


if(user!== null || user !== ""){
sessionStorage.setItem('username', user);
sessionStorage.setItem('password', psw);

window.alert("You are User is:"+user);
window.location.href ="login.html";
}



else{
window.alert("Incorect Username or Password");
}
}


function login(){
window.location.href ="login.html";
}