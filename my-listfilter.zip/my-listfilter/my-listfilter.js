import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';

/**
 * `my-listfilter`
 * Afilterable list app
 *
 * @customElement
 * @polymer
 * @demo demo/index.html
 */
class MyListfilter extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }

        .hidden {
          display: none;
        }
      </style>
      <h2>Basic [[filterProp]]!</h2>

      <ul id="list">
      <li>Hypertext Markup Language</li>
      <li>Cascading Style Sheets</li>
      <li>Javascript</li>
      <li>Web Components</li>
      <li>Polymer</li>
      <li>Web Browser</li>
      <li>Mentally Friendly</li>
    </ul>

      <input value="{{filterProp::input}}" />
    `;
  }
  static get properties() {
    return {
      filterProp: {
        type: String,
        value: '',
        observer: 'filterList'
      }
    }
  }

      filterList() {
        debugger;
        var items = this.$.list.children;        
        for (var i = 0; i < items.length; i++) {
          var item = items[i];
          //if (item.textContent.includes(this.filterProp)) {
            if (item.textContent.toLowerCase().includes(this.filterProp)) {
            item.classList.remove('hidden');
          } else {
            item.classList.add('hidden');
          }
        }
      }

    }

window.customElements.define('my-listfilter', MyListfilter);
